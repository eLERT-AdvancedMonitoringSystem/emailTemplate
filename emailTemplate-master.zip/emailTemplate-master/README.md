# emailTemplate
emailTemplate and VB loader script

To use this template make sure you enable the developers tab in outlook and then download the VBA script and import it into outlook.
Start a new email and go to the developertab and select Macros then click on the Macro to run it. 
The script pulls the html file from github and embeds it as WYSIWYG template in the outlook window.

This VB script is dependent on the Microsoft.Word reference to use this reference: 
  Goto the developer tab > click Visual Basic > Click Tools > Click References > and The Microsoft Word Object Library
  
  Tut here for inserting object https://www.outlook-apps.com/insert-html-to-outlook-emails/
